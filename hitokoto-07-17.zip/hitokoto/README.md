# hitokoto
it's a hitokoto with ajax and api support!
