# 一言纯净API
版本:1.0  
最后更新时间:2017/12/26 00:12
作者:[小俊](https://www.xjisme.com)  
作者博客:[https://www.xjisme.com](https://www.xjisme.com)  
作者地址:[https://www.xjisme.com/138.shtml](https://www.xjisme.com/138.shtml)  
原作者:[小霖](https://xiaolin.in/)  
原作者博客:[https://xiaolin.in/](https://xiaolin.in/)  
原作者地址:[https://xiaolin.in/read/hitokoto-api-xiaolin-edition.html](https://xiaolin.in/read/hitokoto-api-xiaolin-edition.html)  
开发:二次开发,已取得原作者二次开发及开源授权  
开源协议:[GPL v3](https://opensource.org/licenses/GPL-3.0)  
GitHub项目地址:[https://github.com/laulzgoay/hitokoto](https://github.com/laulzgoay/hitokoto)  
码云项目地址:不存在的

版权归作者及原作者所有，任何人不得未经授权修改版权，二次开发请遵守开源协议  
版权所有，侵权必究  
# 更新  
2020/04/14 18:40:增加2条一言
2017/12/26 00:12:增加3条一言
2017/12/25 13:00：头部修改，版本号不变  
# 使用方法
<p id="laulzgoay_hitokoto"></p>
<script type="text/javascript" src="https://api.xjisme.com/hitokoto/?code=js&id=test"></script>

# 请求示例
请求地址:[https://api.xjisme.com/hitokoto/](https://api.xjisme.com/hitokoto/)  
请求方式:GET  
请求参数:Null
返回内容:谁看见过风？我和你，都不曾看见过。  
# 开发文档  
见作者博客:[https://www.xjisme.com/138.html](https://www.xjisme.com/138.html)  
# 注意事项
GBK版本没有JSON和XML格式  
